import React, { useState, useEffect } from 'react';
import './App.css';
import { allRecipes, filter } from './matchRecipes';
import logo from './aliment logo.png';

function App() {
  const [data, setData] = useState<any[]>([]);
  const [veg, setVeg] = useState<boolean>(false);
  const [sea, setSea] = useState<boolean>(false);
  const [sal, setSal] = useState<boolean>(false);
  const [pas, setPas] = useState<boolean>(false);

  useEffect(() => {
    // fetchData();
  }, []);

  async function fetchData() {
    let array: string[] = [];
    if (veg) array.push('Vegetarian');
    if (sea) array.push('Seafood');
    if (sal) array.push('Salad');
    if (pas) array.push('Pasta');

    try {
      const fetchedData = array.length === 0 ? await allRecipes() : await filter(array);
      if (Array.isArray(fetchedData)) {
        setData(fetchedData);
      } else {
        console.error('Unexpected data format:', fetchedData);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  function handleGenerateRecipes() {
    fetchData(); // Call fetchData to generate recipes
  }

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} alt="Logo" className="logo" />
        <p className="title">Welcome to Aliment! Generate some recipes.</p>
        <div className='search-bar'>
          <p>Pretend there is a search bar here.</p>
        </div>
        <div className="checkmark-checkboxes">
          <label>Vegetarian</label>
          <input type="checkbox" checked={veg} onChange={() => setVeg(!veg)} />
          <label>Seafood</label>
          <input type="checkbox" checked={sea} onChange={() => setSea(!sea)} />
          <label>Salad</label>
          <input type="checkbox" checked={sal} onChange={() => setSal(!sal)} />
          <label>Pasta</label>
          <input type="checkbox" checked={pas} onChange={() => setPas(!pas)} />
        </div>
        <button onClick={handleGenerateRecipes} className='button'>Generate Recipes</button>
      </header>
      <body>
        <div>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Prep Time</th>
                <th>Total Time</th>
                <th>Category</th>
              </tr>
            </thead>
            <tbody id="data_output" >
              {data.map((recipe, index) => (
                <tr key={index}>
                  <td>{recipe.name}</td>
                  <td>{recipe.prep_time}</td>
                  <td>{recipe.total_time}</td>
                  <td>{recipe.category}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </body>
    </div>
  );
}

export default App;
