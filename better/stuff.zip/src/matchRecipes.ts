import {Database, Json, Tables} from './database.types';
import {supabase} from './connection';
import {useEffect, useState} from 'react';
import { PostgrestResponse } from '@supabase/supabase-js';
import { NullLiteral } from 'typescript';

// interface Recipe {
//     id : number;
//     name : string;
//     prep_time : number
// }

export const allRecipes = async (): Promise<Json | undefined> => {
    try {  
        let { data: recipes, error } = await supabase
            .from('recipes')
            .select('*')

        
        if (recipes) {
            return recipes;
        }
    } catch (error) {
        console.log('No recipes');
        return undefined;
    }
}


// export const findIngredient = async (keyword: string) => {
//     try {
//         let { data, error} = await supabase
//             .from('keywords')
//             .select('keyword_id, ingredient')
//             .eq('ingredient', keyword);

//         if ({data, error}) {
//             console.log({data, error});
//         }
//     } catch {
//         console.log('No recipes with that ingredient');
//     }
// }

export const filter = async (categories : string[]): Promise<Json | undefined> => {
    try {
        let { data: recipes, error } = await supabase
            .from('recipes')
            .select('*')
            .in('category', categories)
        
        if (recipes) {
            return recipes;
        }
    } catch (error) {
        console.log('No recipes match that category.');
        return undefined;
    }
}

const findRecipesHelper = async (ingredients : string[]) : Promise<PostgrestResponse<any>['data'] | null> => {
    try {
        let { data: ingredient_data, error } = await supabase
            .from('keywords')
            .select('keyword_id')
            .in('ingredient', ingredients)
        
        if (error) {
            throw new Error;
        }
        return ingredient_data;
    } catch (error) {
        return null;
    }
}

